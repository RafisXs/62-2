#include <stdio.h>
#include <string.h>

int main() {
    char filme[100];
    printf("digite o nome de um filme: ");
    fgets(filme, 100, stdin);
    int tam = strlen(filme);
    if (filme[tam - 1] == '\n') {
        filme[tam - 1] = '\0';
        tam--;
    }
    printf("o filme tem %d caracteres\n", tam);
    return 0;
}
