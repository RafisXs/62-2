#include <stdio.h>
#include <string.h>

int main() {
    char p1[30], p2[30], p3[30];
    char frase[100] = "";

    printf("digite a primeira palavra: ");
    fgets(p1, 30, stdin);
    printf("digite a segunda palavra: ");
    fgets(p2, 30, stdin);
    printf("digite a terceira palavra: ");
    fgets(p3, 30, stdin);

    if (p1[strlen(p1) - 1] == '\n') p1[strlen(p1) - 1] = '\0';
    if (p2[strlen(p2) - 1] == '\n') p2[strlen(p2) - 1] = '\0';
    if (p3[strlen(p3) - 1] == '\n') p3[strlen(p3) - 1] = '\0';

    strcat(frase, p1);
    strcat(frase, " ");
    strcat(frase, p2);
    strcat(frase, " ");
    strcat(frase, p3);

    printf("frase: %s\n", frase);
    return 0;
}
