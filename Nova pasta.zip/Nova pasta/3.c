#include <stdio.h>
#include <string.h>

int main() {
    int idade;
    char livro[100];

    printf("digite sua idade: ");
    scanf("%d", &idade);
    getchar();

    printf("digite o titulo do seu livro favorito: ");
    fgets(livro, sizeof(livro), stdin);

    size_t len = strlen(livro);
    if (len > 0 && livro[len - 1] == '\n') {
        livro[len - 1] = '\0';
    }

    printf("\nidade: %d\n", idade);
    printf("livro favorito: %s\n", livro);

    return 0;
}
