#include <stdio.h>

int main() {
    char pais[50];
    printf("digite o nome de um pais: ");
    fgets(pais, 50, stdin);

    char letra = pais[0];
    printf("primeira letra: %c\n", letra);
    printf("codigo ascii: %d\n", letra);

    return 0;
}
