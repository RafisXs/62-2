#include <stdio.h>
#include <string.h>

int main() {
    char nome[50];
    char sobrenome[50];
    char completo[100] = "";

    printf("digite o primeiro nome: ");
    fgets(nome, 50, stdin);
    printf("digite o sobrenome: ");
    fgets(sobrenome, 50, stdin);

    if (nome[strlen(nome) - 1] == '\n')
        nome[strlen(nome) - 1] = '\0';
    if (sobrenome[strlen(sobrenome) - 1] == '\n')
        sobrenome[strlen(sobrenome) - 1] = '\0';

    strcat(completo, nome);
    strcat(completo, " ");
    strcat(completo, sobrenome);

    printf("nome completo: %s\n", completo);
    return 0;
}
