#include <stdio.h>
#include <string.h>

int main() {
    char frase[51];
    printf("digite uma mensagem: ");
    fgets(frase, 51, stdin);

    for (int i = 0; frase[i] != '\0'; i++) {
        if (frase[i] == ' ')
            frase[i] = '-';
    }

    printf("mensagem formatada: %s", frase);
    return 0;
}
