#include <stdio.h>
#include <string.h>

int main() {
    char nome[100];
    char cidade[100];

    printf("Digite seu nome completo: ");
    fgets(nome, sizeof(nome), stdin);

   
    nome[strcspn(nome, "\n")] = '\0';

 
    printf("Digite sua cidade natal: ");
    fgets(cidade, sizeof(cidade), stdin);

 
    cidade[strcspn(cidade, "\n")] = '\0';

 
    printf("%s nasceu na cidade de %s.\n", nome, cidade);

    return 0;
}


