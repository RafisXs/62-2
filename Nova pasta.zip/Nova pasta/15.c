#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char inteiro_str[20];
    char real_str[30];
    char palavra[50];

    printf("digite um numero inteiro: ");
    fgets(inteiro_str, 20, stdin);
    printf("digite um numero real: ");
    fgets(real_str, 30, stdin);
    printf("digite uma palavra: ");
    fgets(palavra, 50, stdin);

    if (palavra[strlen(palavra) - 1] == '\n')
        palavra[strlen(palavra) - 1] = '\0';

    int num_int = atoi(inteiro_str);
    float num_real = atof(real_str);

    printf("inteiro: %d\n", num_int);
    printf("real: %.2f\n", num_real);
    printf("palavra: %s\n", palavra);

    return 0;
}
