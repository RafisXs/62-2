#include <stdio.h>
#include <string.h>

int main() {
    int idade;
    char filme[100];
    char roupa[100];
    char comida[100];
    char livro[100];
    char time[100];

    char *preferencias[5]; 
    char buffer[5][100];   

    printf("digite sua idade: ");
    scanf("%d", &idade);
    getchar();

    printf("digite seu filme favorito: ");
    fgets(filme, 100, stdin);
    printf("digite sua roupa favorita: ");
    fgets(roupa, 100, stdin);
    printf("digite sua comida favorita: ");
    fgets(comida, 100, stdin);
    printf("digite seu livro favorito: ");
    fgets(livro, 100, stdin);
    printf("digite seu time favorito: ");
    fgets(time, 100, stdin);


    if (filme[strlen(filme) - 1] == '\n') filme[strlen(filme) - 1] = '\0';
    if (roupa[strlen(roupa) - 1] == '\n') roupa[strlen(roupa) - 1] = '\0';
    if (comida[strlen(comida) - 1] == '\n') comida[strlen(comida) - 1] = '\0';
    if (livro[strlen(livro) - 1] == '\n') livro[strlen(livro) - 1] = '\0';
    if (time[strlen(time) - 1] == '\n') time[strlen(time) - 1] = '\0';


    strcpy(buffer[0], filme);
    strcpy(buffer[1], roupa);
    strcpy(buffer[2], comida);
    strcpy(buffer[3], livro);
    strcpy(buffer[4], time);
    for (int i = 0; i < 5; i++) {
        preferencias[i] = buffer[i];
    }

    for (int i = 0; i < 4; i++) {
        for (int j = i + 1; j < 5; j++) {
            if (strcmp(preferencias[i], preferencias[j]) > 0) {
                char *temp = preferencias[i];
                preferencias[i] = preferencias[j];
                preferencias[j] = temp;
            }
        }
    }
    printf("\nidade: %d\n", idade);
    printf("preferencias em ordem alfabetica:\n");
    for (int i = 0; i < 5; i++) {
        printf("- %s\n", preferencias[i]);
    }

    return 0;
}
