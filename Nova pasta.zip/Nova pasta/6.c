#include <stdio.h>

int main() {
    char frase[15];
    printf("digite uma frase: ");
    fgets(frase, 15, stdin);
    printf("voce digitou: %s", frase);
    return 0;
}
