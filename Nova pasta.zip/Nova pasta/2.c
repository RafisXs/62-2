#include <stdio.h>
#include <string.h>

int main() {
    char frase[10];  

    printf("digite uma frase (max 9 caracteres): ");
    fgets(frase, sizeof(frase), stdin);

    size_t len = strlen(frase);
    if (len > 0 && frase[len - 1] == '\n') {
        frase[len - 1] = '\0';
    }

    printf("voce digitou: \"%s\"\n", frase);

    return 0;
}


