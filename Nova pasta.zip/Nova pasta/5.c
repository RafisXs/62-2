#include <stdio.h>
#include <string.h>

int main() {
    char nome[100];
    char profissao[100];
    char hobby[100];

    printf("digite seu nome completo: ");
    fgets(nome, sizeof(nome), stdin);

    nome[strcspn(nome, "\n")] = '\0';

    printf("digite sua profissão: ");
    fgets(profissao, sizeof(profissao), stdin);
    profissao[strcspn(profissao, "\n")] = '\0';

    printf("digite um hobby ou passatempo: ");
    fgets(hobby, sizeof(hobby), stdin);
    hobby[strcspn(hobby, "\n")] = '\0';

    printf("bio de %s: um(a) %s apaixonado(a) por %s.\n", nome, profissao, hobby);

    return 0;
}
