#include <stdio.h>
#include <string.h>

int main() {
    char senha[100];

    printf("digite sua senha: ");
    fgets(senha, sizeof(senha), stdin);

    size_t len = strlen(senha);
    if (len > 0 && senha[len - 1] == '\n') {
        senha[len - 1] = '\0';
        len--;
    }

    if (len >= 8) {
        printf("senha valida\n");
    } else {
        printf("senha invalida\n");
    }

    return 0;
}
