#include <stdio.h>
#include <string.h>

int main() {
    char palavra[100];
    printf("digite uma palavra: ");
    fgets(palavra, 100, stdin);
    int tam = strlen(palavra);
    if (palavra[tam - 1] == '\n') {
        palavra[tam - 1] = '\0';
        tam--;
    }
    printf("voce digitou uma palavra com %d letras\n", tam);
    return 0;
}
