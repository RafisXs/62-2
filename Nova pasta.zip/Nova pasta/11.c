#include <stdio.h>
#include <string.h>

int main() {
    char nome1[50], nome2[50];
    printf("digite o primeiro nome: ");
    fgets(nome1, 50, stdin);
    printf("digite o segundo nome: ");
    fgets(nome2, 50, stdin);

    if (nome1[strlen(nome1) - 1] == '\n')
        nome1[strlen(nome1) - 1] = '\0';
    if (nome2[strlen(nome2) - 1] == '\n')
        nome2[strlen(nome2) - 1] = '\0';

    if (strcmp(nome1, nome2) == 0)
        printf("nomes iguais\n");
    else
        printf("nomes diferentes\n");

    return 0;
}
